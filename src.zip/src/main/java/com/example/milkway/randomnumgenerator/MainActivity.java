package com.example.milkway.randomnumgenerator;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button ADV;
        ADV = (Button) findViewById(R.id.toAdvice);
        {
            //给button(ADV) 设置监听事件
            ADV.setOnClickListener(new View.OnClickListener() {
                @Override
                // 用Intent 设置跳转，点击按钮跳转新页面。
                public void onClick(View v)
                {
                    Intent intent = new Intent(MainActivity.this, feedback.class);
                    startActivity(intent);
                }
            });
        }
    }

    public void generate(View view)
    {
        EditText upper_bound = (EditText)findViewById(R.id.ub);
        EditText lower_bound = (EditText)findViewById(R.id.lb);
        int upper = Integer.parseInt(upper_bound.getText().toString());
        int lower = Integer.parseInt(lower_bound.getText().toString());
        int random = new Random().nextInt(upper);
        int res = lower + (random % (upper-lower));
        display(res);
    }

    private void display(int number) {
        String show = "" + number;
        TextView quantityTextView = (TextView) findViewById(R.id.ResView);
        quantityTextView.setText(show);
    }



}
