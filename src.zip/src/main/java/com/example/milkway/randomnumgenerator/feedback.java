package com.example.milkway.randomnumgenerator;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

/**
 * Created by Milkway on 2017/5/30.
 */

public class feedback extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.feedback);
    }

    public void submit(View view)
    {
        EditText adviceEdit = (EditText)findViewById(R.id.advice);
        String AdviceToSent=""+adviceEdit.getText().toString();

        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:"));
        intent.putExtra(Intent.EXTRA_EMAIL,"379087902@qq.com");
        intent.putExtra(Intent.EXTRA_SUBJECT,"Some advice for you!");
        intent.putExtra(Intent.EXTRA_TEXT,AdviceToSent);
        if(intent.resolveActivity(getPackageManager())!=null)
        {
            startActivity(intent);
        }
    }
}
